import requests
import json

mapquestKey ="qJKZZGpVI48SsaCyCdlM6RwVruCDdvJK"

url = "http://www.mapquestapi.com/geocoding/v1/address?key=" + mapquestKey + "&location=Basak+Pardo"
url2 = "http://www.mapquestapi.com/geocoding/v1/address?key=" + mapquestKey + "&street=1600+Pennsylvania+Ave+NW&city=Washington&state=DC&postalCode=20500"

data = requests.get(url).json()                         #Get the 'whole' weather data from the link/ur

print(data)