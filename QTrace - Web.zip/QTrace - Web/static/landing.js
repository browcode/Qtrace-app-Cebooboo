const signinMessage = document.getElementById("signinMessage");
const signup = document.getElementById("signup");


function formatting(){
    signinMessage.classList.add("textXSmall");
    signup.classList.add("primaryButton");
    signup.classList.add("MtextSmall")
    signup.classList.add("primaryButton");
    signinMessage.classList.add("MtextXSmall");
}