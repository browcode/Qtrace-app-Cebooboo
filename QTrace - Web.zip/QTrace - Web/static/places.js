const box = document.getElementById("box");
const nav = document.getElementById("nav");
var currentDay = document.getElementById("daySlider").value;
const time = document.getElementById("time");


function initialize() {
    var myLatlng = new google.maps.LatLng(10.2779285,123.8774052)
    var mapOptions = {
    zoom: 14,
    center: myLatlng,
    mapTypeId: google.maps.MapTypeId.ROADMAP
    }
    var markers = [];
    function setMapOnAll(map) {
        for (let i = 0; i < markers.length; i++) {
            markers[i].setMap(map);
        }
    }
    var slider = document.getElementById("daySlider");
    slider.addEventListener("change", function(){
        Day = this.value;
    })
    function clearMarkers() {
        setMapOnAll(null);
    }
    function deleteMarkers() {
        clearMarkers();
        markers = [];
    }
    var map = new google.maps.Map(document.getElementById('map_canvas'), mapOptions);
    if (Day == 23){
        latlng = myData["11/23/20"]["LatLng"];
        for (var x = 0; x < latlng.length; x++){
            var newLatlng = new google.maps.LatLng(latlng[x]["lat"], latlng[x]["lng"]);
            var marker = new google.maps.Marker({
                position: newLatlng,
                map: map
            });
            markers.push(marker);
            var options = {
                imagePath: 'http://rawgit.com/googlemaps/js-marker-clusterer/gh-pages/images/m'
            }
        }
    }
    else{
        alert("false");
        deleteMarkers();
    }
    var markerCluster = new MarkerClusterer(map, markers, options);

}














       

var opened = false;
box.addEventListener("click", function(){
    if (opened == false){
        nav.classList.add("expand");
        nav.classList.remove("compress");
        opened = true;
    }
    else{
        nav.classList.remove("expand");
        nav.classList.add("compress");
        opened = false;
    }
})