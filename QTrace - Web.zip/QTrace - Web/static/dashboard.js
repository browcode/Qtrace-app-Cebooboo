var navs = document.getElementsByTagName("li");

function formatting(){
    for (var x = 0; x <navs.length; x++){
        navs[x].classList.add("MlinkSmall");
    }
}