const message01 = document.getElementById("message01");
const message02 = document.getElementById("message02");
const message03 = document.getElementById("message03");
const navs = document.getElementsByTagName("li");

function formatting(){
    message01.classList.add("displayLargeBold");
    message02.classList.add("displayLarge");
    message03.classList.add("displaySmall");
    for (var x = 0; x < navs.length; x++ ){
        navs[x].classList.add("linkSmall");
    }
}
