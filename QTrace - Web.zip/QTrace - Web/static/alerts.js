const card = document.getElementsByClassName("card");
const Span = document.getElementsByTagName("span");
const navs = document.getElementsByTagName("li");

function formatting(){
    for (var x = 0; x < card.length; x++){
        card[x].classList.add("textMedium");
    }
    for (var x = 0; x < Span.length; x++){
        Span[x].classList.add("displaySmallBold");
    }
    for (var x = 0; x < navs.length; x++){
        navs[x].classList.add("linkSmall");
    }
}