const navs = document.getElementsByTagName("li");
const signinMessage = document.getElementById("signinMessage");
var w = document.documentElement.clientWidth;
const mmessage01 = document.getElementById("mmessage01");
const mmessage02 = document.getElementById("mmessage02");
const mcitizen = document.getElementById("mcitizen");
const mestablishment = document.getElementById("mestablishment");
const mcontactTracer = document.getElementById("mcontactTracer");
const signInMessage = document.getElementById("signInMessage");


window.addEventListener("resize", function(){
    w = document.documentElement.clientWidth;
    formatting();
})
function formatting(){
    if (w > 600){
        signinMessage.classList.add("textSmall");
        for (var x = 0; x < navs.length; x++){
            navs[x].classList.add("linkSmall");
        }
    }
    else{
        mmessage01.classList.add("MdisplayLargeBold");
        mmessage02.classList.add("MtextSmall");
        mcitizen.classList.add("MlinkSmall");
        mestablishment.classList.add("MlinkSmall");
        mcontactTracer.classList.add("MlinkSmall");
        signInMessage.classList.add("textSmall");
        
    }

}