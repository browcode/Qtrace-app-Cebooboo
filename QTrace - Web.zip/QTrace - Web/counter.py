import json
import codecs
fname = input('Enter file name: ')
fhand = open(fname)
LatLng = list()
Day = dict()
data = dict()
handler = codecs.open('data.js', 'w', "utf-8")
handler.write("myData = {\n")
for line in fhand:
    if not line.startswith('['): continue
    piece = line.strip().split(",")
    if piece[-1] == '':
        day = piece[-2][1:9]
    else:
        day = piece[-1][1:9]
    Day[day] = Day.get(day, 0) + 1

fhand.close()
sfhand = open(fname)
for day in Day:
    for sline in sfhand:
        if not sline.startswith('['): continue
        piece = sline.strip().split(",")
        if piece[-1] == '':
            theday = piece[-2][1:9]
        else:
            theday = piece[-1][1:9]
        print(theday)
        print(day)
        if day == theday:
            lat = piece[0][1:]
            lng = piece[1]
            latlng = {"lat": lat, "lng": lng}
            #latlngS = json.dumps(latlng)
            LatLng.append(latlng)   
    output = "'"+str(day)+"': {\n" + "'freq':" + str(Day[day]) +", "+ "'LatLng':" + str(LatLng) + "\n}\n"
    handler.write(output)
handler.write("\n};\n")
handler.close()